# GastaBot AGS — v2.5

«Dime tu presupuesto y qué se te antoja; te armo un combo de compras en la plaza.»

## Instalar
1. Descomprime → Chrome → `chrome://extensions` → **Modo desarrollador** → **Cargar descomprimida**.
2. Clic en el ícono → chatbot en el panel lateral. Funciona de inmediato en **modo local** (sin claves).

## Novedades v2.5 — Login tardío, Rappi y locales en los mensajes, comida local
- **Inicio de sesión después del primer mensaje:** al abrir la app ves todo directo. Tras tu primer mensaje aparece «¿Quieres seguir recibiendo recomendaciones?» con el formulario y, siempre, **Seguir sin cuenta** (todo funciona igual). Se pregunta una sola vez por sesión.
- **Franja «Más opciones» bajo cada respuesta:** Rappi (con lo que pediste), DiDi Food, A domicilio, **Comida local**, Productos locales y Cerca de mí.
- **Recomendaciones locales en cada respuesta:** además de los productos de negocios locales, ahora sale **comida local barata** que cabe en tu presupuesto (rota entre mensajes para que haya variedad).
- **Comida local** (`restaurantes.js`, plaza «Restaurantes locales», entra en cualquier búsqueda): 22 negocios y 70 platillos con foto/ilustración, descripción, rango de precio y botón para buscar en el mapa (cerca de ti si diste ubicación).
  - 12 lugares con nombre, mencionados en fuentes públicas (Grupo Animal, Mexico News Daily, Tus Buenas Noticias, Carta.menu, Uber Eats). De cada uno sólo se toma qué tipo de comida se le menciona.
  - 10 «tipos de negocio» (taquerías, fondas, tortas, pozole y menudo, gorditas y tamales, esquites y elotes, pollo asado, mariscos, desayunos, postres).
  - **Los precios son estimados míos** (marcados «~» y «?»), no el menú de cada negocio; confirma en el lugar.
- Fotos y glifos nuevos: 26 tipos de platillo mexicano (birria, barbacoa, carnitas, pozole, gorditas…).

## Novedades v2.4 — Cerca de mí
- Tarjeta **Cerca de mí** en el inicio: con tu ubicación (te pide permiso) ordena las plazas de la más cercana a la más lejana, con la distancia **en línea recta**, las tiendas con oferta o menú de cada una, **Cómo llegar** (abre Google Maps) y **Armar combo aquí** (cambia tu plaza y te deja listo para escribir el presupuesto). También puedes elegir a mano dónde estás.
- En **Precios locales**, «Buscar cerca de mí» centra los enlaces de «Dónde buscarlo» (maderería, tapicería, abarrotes…) en tu ubicación.
- **Privacidad:** tu ubicación queda en la memoria de la pestaña; no se guarda ni se manda a GastaBot ni a Supabase. Lo único que se consulta afuera es la dirección de cada plaza (no tu ubicación) en OpenStreetMap, y se guarda 90 días.
- Coordenadas: Espacio y Centro tienen punto fijo; Altaria, Villasunción y Galerías se ubican buscando su dirección en OpenStreetMap. Si una no se encuentra aparece sin distancia (no se inventan coordenadas). La ubicación sólo funciona en páginas https o en la app instalada.
- Archivo nuevo: `near.js`.

## Novedades v2.3 — fotos para todo y productos locales
- **Fotos para todo, también en el celular:** la app busca sola una foto de referencia de cada tipo de producto (ropa, calzado, accesorios, comida, muebles, pantallas, motos…) en **Wikimedia Commons** (licencias libres, con crédito; sin clave) o en **Pexels** si pones tu clave. Se guardan 30 días en el dispositivo. La foto sólo se acepta si su título coincide con el tipo; si no, se queda la ilustración. Son fotos «de referencia», no del modelo exacto. Requiere internet; sin conexión se ven las ilustraciones.
- Productos del catálogo de PDFs (v2.2) que no traen foto (Coppel, Sephora, Flexi) ahora también reciben foto por tipo. Los de Liverpool y Zara conservan la foto real de la tienda.
- **Precios locales: 100 productos de referencia** (abarrotes, mercado, materiales, servicios, refacciones, telas, otros) con **foto**, **rango estimado** y **dónde buscarlo** (con enlace al mapa). Son estimaciones mías, **sin fuente oficial**: se marcan «Estimado». Sólo hay nombres propios donde una fuente pública los confirma (Central de Abasto, Mercado Jesús Terán).
- Nuevos tipos con ilustración de respaldo: pantallas, camas, roperos, motos, huevo, pan, granos, verduras, carnes, madera, cemento, pintura, tubería, telas, refacciones, servicios.
- Archivos nuevos: `locales.js`.
- No pude probar contra Wikimedia/Pexels reales desde mi entorno (están bloqueados); el flujo se probó con respuestas simuladas. Si alguna foto sale mal, avísame el producto.

## Novedades v2.2 — catálogo cargado de PDFs (con fotos y precios)
- **638 productos** de las páginas de **Liverpool** (295: calzado y perfumes), **Zara** (60), **Sephora** (143), **Coppel** (119: muebles, celulares, pantallas y motos) y **Flexi** (21). Precios web del 2026-11-19 (con «Antes $X» cuando había descuento); los verifiqué uno por uno contra el texto de los PDFs.
- **Fotos reales** de Liverpool y Zara (355), recortadas a miniatura. Coppel, Sephora y Flexi vinieron sin fotos en los PDF: usan la ilustración (o las fotos de referencia de Pexels si pones tu clave).
- La página de cada tienda ahora tiene **buscador, filtro por categoría y «Ver más»**, y muestra primero los productos con precio real.
- Los combos del presupuesto ya usan estos productos (precio exacto, no estimado).
- Archivos: `catalogo.js` (datos), `img/c/` (fotos). En `gastabot-celular.html` las fotos van incrustadas (pesa ~1.7 MB).
- Para actualizar: pásame PDFs nuevos de las páginas de las tiendas y regenero el catálogo.
- Limitación: mi entorno no puede bajar fotos de bancos gratis (Pexels/Unsplash/Wikimedia), así que no pude pre-guardar fotos de relleno; los productos sin foto usan la ilustración.

## Novedades v2.1 — Precios locales
- Pantalla **Precios locales** (tarjeta en el inicio y entrada en el menú) para lo que no está en internet: madera, materiales, **abarrotes**, mercados y mayoreo, servicios, refacciones, telas y otros.
- **Comparador**: agrupa por producto y unidad, muestra mínimo–máximo, mediana, el lugar más barato visto y la fecha; los datos de más de 90 días se marcan como viejos. Cada precio tiene «Sigue así / Ya cambió», mapa y reporte.
- **Registrar un precio** a mano o con **foto de una lista de precios** (Claude la lee, tú corriges y confirmas renglón por renglón).
- **Necesito cotización**: pides un precio y otros responden registrándolo.
- **Referencias oficiales con fuente**: sólo se incluye lo verificable (hoy: huevo, Central de Abasto de Aguascalientes, SNIIM). No hay precios inventados.
- Para activarlo en la nube: correr `supabase/prices.sql`; la lectura de listas usa la misma función `gastabot-offer-scan` (vuelve a pegar su `index.dashboard.ts`, ahora con modo «precios»). Sin nube, todo queda en tu dispositivo.

## Novedades v2.0 — A domicilio (Rappi y DiDi Food)
- Página **A domicilio** (tarjeta en el inicio y entrada en el menú): buscador que abre **Rappi** con lo que escribas, atajos (pizza, tacos, sushi…) y enlace a la página de **DiDi Food Aguascalientes**.
- En cada lugar de comida (ficha del producto y menú) aparecen «Buscar en Rappi» y «DiDi Food».
- **No hay conexión a datos de Rappi ni DiDi**: sus APIs son sólo para restaurantes aprobados; la app abre sus sitios/apps. DiDi no tiene buscador web para clientes, por eso sólo se enlaza su página de la ciudad.

## Novedades v1.9 — promociones al día (comunidad + foto)
- **Vigencia obligatoria**: toda oferta de Comunidad lleva «vigente hasta» (máx. 120 días) y desaparece sola al vencer.
- **«¿Sigue vigente?» Sí / Ya no**: cualquiera (menos quien la publicó) confirma; con 3 «ya no» y más «ya no» que «sí», se oculta sola.
- **Ofertas de la comunidad** aparecen en la página Ofertas, abajo de las oficiales, marcadas como *No verificadas*.
- **Foto a oferta**: subes el cartel o una captura y Claude pre-llena tienda, oferta y fecha. **Tú revisas y publicas**; la foto no se guarda. Requiere nube + función `gastabot-offer-scan`.
- Para activarlo: correr `supabase/community2.sql`; desplegar `gastabot-offer-scan/index.dashboard.ts` con el secreto `ANTHROPIC_API_KEY` (el mismo del chat). Sin la función, todo lo demás funciona.

## Novedades v1.8 — más plazas: Galerías y Centro
- Plazas nuevas: **Galerías Aguascalientes** (Av. Independencia 2351) y **Centro** (Plaza Patria, El Parián, calles Madero y Nieto). Salen en el selector de plaza, en «Agregar», en Comunidad y en el chat («$300 en Plaza Patria»).
- Hay pocas tiendas y **todas sin verificar** (se muestran con «?»): no existen directorios confiables de locales pequeños y no se inventan negocios. Los locales de comida y ropa del Centro los agregas tú en «Agregar» (o los pasas y se cargan en la siguiente versión).
- Al escribir «centro comercial» ya no se confunde con la plaza «Centro».
- Si usas el chat con Claude en Supabase, vuelve a pegar `gastabot-chat/index.dashboard.ts` (ahora reconoce las plazas nuevas) y, si usas correos, `gastabot-digest/index.dashboard.ts`.

## Novedades v1.7 — notificaciones (campanita)
Campanita con contador en la barra superior. Avisa de: ofertas nuevas de tus tiendas ⭐, ofertas que vencen hoy o mañana, me gusta en tus publicaciones de Comunidad y ofertas nuevas de la comunidad en tu plaza. Se activan o apagan por tipo dentro de la misma pantalla. Se revisan al abrir la app y cada 3 minutos mientras está abierta; **no son push** (no llegan con la app cerrada).

## Novedades v1.6 — Comunidad y chat a la vista
- **Comunidad**: botón en la barra superior, tarjeta en el inicio y entrada en el menú. Se publican ofertas, lugares recomendados e ideas; hay filtros, orden por votos, me gusta, reportar (3 reportes de personas distintas la ocultan) y borrar las propias.
- Con la nube activada es compartida entre todos: corre `supabase/community.sql` una vez. Sin nube queda sólo en tu dispositivo.
- El cuadro de chat ahora aparece **debajo del presupuesto** en la pantalla inicial; con el primer mensaje vuelve abajo, como siempre.

## Novedades v1.5 — recomendaciones por correo de tus tiendas favoritas
Con cuenta en la nube, en **Perfil** activas «Mandarme por correo recomendaciones» (semanal o mensual). Recibes, por cada tienda ⭐: ofertas vigentes, 3 productos y opciones parecidas de **otras marcas** (etiquetadas). Precios con «~» son estimados.
Requiere montarlo una vez en Supabase (ver `supabase/README.md`, sección «Correos»): correr `supabase/digest.sql`, desplegar `gastabot-digest`, poner secretos (`RESEND_API_KEY`, `DIGEST_FROM`, `DIGEST_SECRET`) y programar el cron. Sin eso, el interruptor se guarda pero no se envía nada. Lo demás no cambió.

## Novedades v1.4 — se quitó lo que no estaba verificado
- Antes desglosé productos de muchas tiendas según su giro (p. ej. «Tacones» en una tienda de ropa) sin haberlo confirmado. **Ahora solo se desglosa lo verificado en catálogo público**: calzado de Liverpool, Flexi y Cuadra (consultado 2026-11-19). Las demás tiendas conservan su producto genérico del catálogo original. Los productos con nombre y precio de `menus.js` no cambian.
- Para añadir una tienda al desglose, mándame su catálogo (enlace, captura o PDF) y la cargo como datos verificados.

## Novedades v1.3 — ilustración propia por tipo de producto
- Sin clave ni internet: cada tipo tiene su **ilustración** (tacón, sandalia, mocasín, tenis, bota vaquera, polo, falda, gorra, anillo, collar, pulsera, aretes, celular, cable, lámpara, colchón, balón, pesas, control, calcetines, pijama…). Siempre coincide con el producto. Las fotos de Pexels siguen siendo opcionales (Ajustes).

## Novedades v1.2 — fotos seguras (ojo: requieren clave gratuita)
- **Se quitó Wikimedia como fuente de fotos**: mezclaba productos y a veces traía imágenes inadecuadas. Ahora la fuente es **Pexels** (fotos curadas, con descripción, sin contenido adulto). Se guarda en Ajustes → «Fotos de productos (Pexels, gratis)». **Sin clave no hay fotos**: solo ilustraciones (nunca una foto equivocada).
- Una foto se acepta solo si su descripción coincide con el tipo del producto, no menciona otro tipo y no contiene términos sugerentes. Los créditos (fotógrafo y enlace) se muestran bajo la foto.
- Fotos exactas de cada modelo: captura el producto con su `img` o mándame los catálogos (enlaces, PDF, capturas o un CSV con tienda, producto, precio y URL de imagen) y los cargo como datos reales.

## Novedades v1.1 — fotos que sí corresponden al producto y variedad interactiva
- **Cada producto tiene un TIPO exacto** (tacones, botines, bota vaquera, tenis skate, polo, jeans, anillo, labial, Big Mac…). Antes todo el calzado se buscaba como «tenis»; ahora un tacón de Liverpool nunca trae un tenis de portada. Los tipos y el vocabulario viven en `visual.js`.
- **La foto solo se acepta si su título o descripción coincide con el tipo** (y no contiene palabras de otro tipo). Si ninguna coincide —o no hay internet— se queda la ilustración. Cada producto toma una foto distinta del conjunto de su tipo, así no se repite la misma en todo.
- **Fotos de la marca cuando existen** (Vans, Crocs, Levi's, Big Mac, Whopper, Starbucks…): se busca primero la foto de la marca y, si no hay, la del tipo. Debajo de cada foto se dice cuál es: «Foto de {marca}» o «Foto de referencia de “Tacones”; no es el modelo exacto de {tienda}». Para fijar la foto exacta de un producto: `PINNED["idTienda|Nombre"]` en `photos.js` (o captura el producto con su `img`).
- **Variedad dentro de la ficha**: una tira con los tipos que vende la tienda (p. ej. en Liverpool: Tacones, Botines, Tenis casuales, Zapatos de vestir, Sandalias, Flats, Mocasines). Al tocar uno cambian fotos, descripción, precio y la barra del combo. En tiendas con productos concretos (menús) la tira muestra otros productos de la misma categoría.
- **Aviso de marca**: las opciones parecidas, el mini catálogo, la comparación y las alternativas del combo llevan la etiqueta **«Otra marca»** y un mensaje: «no son de {marca}: son productos parecidos que quizá te gusten». Nuevo filtro **«Otras marcas»** en el mini catálogo. El mismo producto en otra plaza ya no cuenta como «parecido».
- **Más productos reales por tienda**: los productos genéricos del catálogo (Zapatos, Playera, Pantalón, Joyería…) se desglosan en los tipos que cada tienda publica en su catálogo en línea (consultado 2026-11-19: Liverpool, Flexi, Cuadra, Zara, Mango; el resto, según el giro de la marca). **Los precios siguen siendo estimaciones**: cada tipo toma un tramo del rango de la tienda. Los chats guardados con los nombres anteriores siguen abriendo (`aka`).
- Ahora «tacones», «botines», «mocasines», «sandalias»… se entienden como búsqueda de calzado.

## Novedades v1.0 — ficha de producto y mini catálogo
- **Toca cualquier producto** (en el combo, en una comparación, en un menú de tienda) y se abre una **ficha** (hoja inferior; se cierra con la X, arrastrando hacia abajo o con Esc). El chevron ▾ del combo sigue abriendo las alternativas rápidas.
- **Galería**: hasta 4 fotos deslizables con miniaturas, contador y puntos. Son **fotos de referencia del tipo de producto** (Wikimedia Commons, licencias libres, con autor y licencia debajo de la foto); si capturas un producto con `img`, esa va primero. Sin internet se queda la ilustración.
- **Nivel de calidad** (Básico · Estándar · Premium) con «Por qué». **Ojo:** el catálogo no trae materiales ni especificaciones, así que el nivel se **calcula** con la posición del precio dentro de su categoría, si la tienda está confirmada, si el precio es de lista publicado, calificación y ofertas. Si capturas un producto con `quality` (0, 1 o 2) o `specs` (lista de textos), la ficha usa eso en vez del cálculo (`catalog.js`).
- **Opciones parecidas**: 6 productos de la misma categoría con diferencia de precio («$120 menos») y nivel de calidad. Al tocar una se llena la **comparación rápida** y puedes **elegirla** (o agregarla) sin salir de la ficha.
- **Mini catálogo** de la categoría con filtros Todo · Más barato · Mejor calidad · Misma tienda y botón **+** para sumar al combo (sólo si te alcanza).
- **Barra del combo** dentro de la ficha: muestra cómo quedaría tu presupuesto con esa opción (diferencia, «te pasas por…»).
- Diseño: prototipo hecho en Lovable (proyecto «GastaBot AGS») y trasladado a HTML/CSS plano.

## Novedades v0.9
- **Chat con IA opcional (Claude)**: Claude entiende lo que escribes (saludos, charla, «me sobra, quiero algo de olor rico») y redacta una respuesta corta; los precios, tiendas y combos los sigue calculando el motor de reglas, así que no inventa datos. Si no hay internet, crédito o la función falla, vuelve solo a las reglas.
- La clave de Anthropic vive **sólo** como secreto en una función de Supabase (`supabase/functions/gastabot-chat`). Instrucciones paso a paso en `supabase/README.md`. Se activa en Ajustes con «Usar IA en el chat».
- Protecciones: la respuesta del modelo se valida y limpia (intención, monto, categorías, plaza), el texto del usuario se trata como dato, hay límite por IP y tope diario.

## Novedades v0.8
- **Menú a la izquierda**: el logo «gastabot» (con ☰) abre el panel lateral: Inicio, Nuevo chat, chats recientes, Menús de la plaza, Ofertas, Favoritos, Agregar, Historial, Cuenta, Ajustes, Cómo se usa y Créditos de fotos.
- **El chat recuerda tu combo**: «agrega un perfume» suma esa categoría con lo que te queda; «agrega una sudadera» te muestra opciones que sí te caben con botón **+ Agregar**; «¿qué más me alcanza?» también funciona. Lo agregado se puede quitar con el bote de basura. El margen se calcula con precios mínimos (el «hasta $X» del botón). Si no alcanza, te dice cuánto falta y ofrece rearmar o subir el presupuesto.
- **Relieves**: filas, opciones, chips y botones se elevan al pasar el cursor y se hunden al tocar.
- **Fotos reales** (Wikimedia Commons, licencias libres): cada producto busca una foto de su tipo (playera blanca, jeans, hamburguesa…). Se guarda en el dispositivo y, si no hay internet o no hay buena foto, se queda la ilustración. Autor y licencia en Menú › Créditos de fotos. Para fijar una foto exacta usa `PINNED` en `photos.js`.
- **`gastabot-celular.html`**: toda la app en un solo archivo. Ábrelo en el celular (o publícalo como página). En esa versión las fotos remotas no cargan si el sitio las bloquea; se ven las ilustraciones.

## Novedades v0.7.1
- **El logo «gastabot» te lleva al inicio** (pantalla de bienvenida con presupuesto y categorías).
- **Panel lateral tipo chat**: botón ☰ abre un panel oscuro con «Nuevo chat», chats recientes y, abajo, Menús de la plaza, Ofertas, Favoritos, Agregar, Historial, Cuenta, Ajustes y Cómo se usa.
- **Bienvenida con Ejemplos / Qué hago / Límites**; los ejemplos se tocan para probarlos.
- **Conversación**: responde saludos («holaaa»), «¿cómo estás?», gracias, adiós, «¿quién eres?» y «ayuda»; si no entiende, lo dice y sugiere ejemplos. Entiende «menú de Chili's» y «¿y con 1000?» (reutiliza lo que pediste antes).

## Novedades v0.7
- **Recuerda tu presupuesto**: lo guarda entre mensajes y al cerrar la app. Si escribes «una sudadera negra» sin monto, usa el último. Aparece como etiqueta «Presupuesto $X» arriba; tócala para cambiarlo. Si escribes otro monto, lo actualiza.
- **Menú más sobrio**: íconos de línea, paleta neutra, sin emojis.
- **Imágenes para todo**: ilustraciones vectoriales por tipo de producto (playera, sudadera, jeans, tenis, perfume, labial, hamburguesa, pizza, sushi, café…) en ropa, calzado, perfumes, belleza y comida. Foto real sólo si el producto trae `img`.
- **Perfumería más allá de Sephora**: Liverpool, Sears y Sephora con productos concretos (Good Girl, Bleu de Chanel, Dylan Blue, Libre, Sauvage, body mist, sets).
- **Siempre 5 opciones distintas**, en el combo y en el comparador.
- **Más menús con precios**: Chili's, Italianni's, Sushi Roll, Subway y Wendy's (fuentes: fastfoodsmenu.com, Rappi y prensa), además de ropa y calzado en Liverpool, Sears, Levi's, H&M, Zara, Bershka, Pull&Bear, American Eagle, Vans, Adidas, Puma, Skechers y Flexi.
- **App descargable (APK)**: `package.json` + `capacitor.config.json` + `.github/workflows/android.yml`. Sube la carpeta a un repositorio de GitHub, ve a Actions › «Construir APK de Android» › Run workflow y descarga `GastaBot-AGS-apk` (un `app-debug.apk` que se instala en Android). No pude compilarlo aquí (el entorno no tiene el SDK de Android), así que ese flujo no está probado. En iPhone se instala como PWA (Compartir › Agregar a inicio); una app de App Store requiere cuenta de desarrollador de Apple.

### Honestidad de precios v0.7
- Sin «~» = precio publicado (con fuente y fecha en la tienda). Con «~» = rango estimado.
- Ropa de H&M, Zara, Bershka, Pull&Bear, Adidas, Puma, Skechers y Flexi: rangos estimados, no hay lista pública de la sucursal.
- Los precios de apps de reparto (Rappi) suelen ser más altos que en mostrador.

## Novedades v0.6
- **Productos concretos**: ya no es «Burger King ~$170». Ahora es «Combo Whopper $179 (Whopper + papas + refresco)», «Whopper sola ~$126», etc. Menús con productos y precios para Burger King, McDonald's, Starbucks, Domino's, KFC y Carl's Jr. (precios de referencia de prensa y apps de reparto, nov-2026) y estimados para Subway, Wendy's, Chili's, Italianni's, Sushi Roll, Gong Cha y Cinépolis (se muestran con «~»). Escribe «la whopper» o «big mac» y compara variantes.
- **Menú de cada tienda**: toca el nombre de la tienda (o Menú › Menús de la plaza) para ver su carta, con filtro Combos / Solos.
- **Imágenes**: mosaico de color con ilustración del producto. Foto real sólo si capturas el producto por link (campo `img`). No descargo fotos de marcas por mi cuenta.
- **Más color y movimiento**: tono por categoría, menú en mosaicos, números que corren, barra que crece, animación sólo al llegar un mensaje nuevo (se respeta «reducir movimiento»).
- **App de celular (PWA)**: instalable desde el navegador, funciona sin conexión. Ver abajo.

## Instalar en el celular (PWA)
1. Sube esta carpeta a un hosting con HTTPS (el más fácil: https://app.netlify.com/drop — arrastras la carpeta y te da un link; también sirve GitHub Pages).
2. Abre el link en el celular. **Android (Chrome):** Menú › «Instalar en mi celular» (o el aviso de Chrome). **iPhone (Safari):** Compartir › «Agregar a pantalla de inicio».
3. Tus chats y favoritos se guardan en ese navegador. Para llevarlos a otros dispositivos usa cuenta en la nube (Supabase).
Límites: en la versión web el «Producto por link» casi nunca funciona (los sitios bloquean la lectura desde otra página); captura precio e imagen a mano. La extensión de Chrome sí pide permiso por sitio.
Si cambias archivos, vuelve a copiar `sidepanel.html` a `index.html` y sube la versión de `CACHE` en `sw.js`.

## Novedades v0.5
- **Opciones concretas:** cada compra del combo trae 3–4 alternativas de precio distinto (barata → premium). Tócala y se recalcula la barra de presupuesto. El comparador muestra 4 y «Ver N más».
- **Imágenes:** foto del producto (si la capturas con «Producto por link») → logo de la tienda (favicon vía servicio de Google, necesita internet) → ícono de categoría. No hay fotos reales de todo el catálogo: la semilla trae rangos, no fotos.
- **Producto por link:** Agregar → pega el link → trae imagen y precio **solo si la página los publica** (og:image / JSON-LD). Si no, los escribes. Pide permiso por sitio.
- **Diseño minimalista** nuevo (papel, tinta, verde billete; barra de presupuesto segmentada).
- **Inicio de sesión:** pantalla de bienvenida. Sin Supabase es un perfil local (nombre/correo, solo en este navegador); con Supabase son cuentas reales.
- **Chats guardados:** Historial (🕘) abre, continúa o borra chats. Local (50 máx.) o sincronizados si usas Supabase (vuelve a correr `schema.sql`: agrega la tabla `chats`).

## Qué hace (v0.2)
| Función | Estado |
|---|---|
| Estructura **Ciudad › Plaza › Tienda › Productos (rango)** | ✅ lista para cualquier plaza de México |
| **Combo** por presupuesto («$1,500, ropa y perfume») con gasto, sobrante y extra de café | ✅ (planificador por reglas, no LLM) |
| **Modo ruta** (compras primero, comida al final) | ✅ orden sugerido; ❌ sin mapa interno |
| **Comparador** («una sudadera negra») | ✅ más económica; «mejor calificada» si hay ratings de Google |
| **Detector de presupuesto** (oculta tiendas donde nada entra) | ✅ |
| **Ofertas manuales con vigencia** (admin, <1 min) | ✅ |
| **Google Places** para descubrir tiendas de la plaza | ✅ código listo; necesita tu API key |
| **Nube Supabase**: cuentas, favoritos, historial, tiendas y ofertas compartidas | ✅ código + `schema.sql`; necesita tu proyecto |
| Ofertas **automáticas** desde sitios de las tiendas | ❌ pendiente |
| Panel para que **las tiendas** suban productos/cupones | ❌ pendiente (v0.3) |
| Catálogos/feeds oficiales con precios reales | ❌ pendiente |

## Sin tarjeta: OpenStreetMap (v0.3)
Ajustes → elige plaza → **Sincronizar desde OpenStreetMap**. Es gratis y no necesita clave. Trae menos tiendas que Google y los rangos son estimados por categoría. Código probado con respuestas simuladas; no pude consultar el servidor real desde mi entorno, así que si falla, avísame con el mensaje.

## Activar Google Places (opcional, requiere tarjeta)
1. Google Cloud → habilita **Places API (New)** → crea una API key y **restríngela** (sólo esa API).
2. Ajustes → pega la key → elige una plaza arriba → **Sincronizar plaza desde Google**.
3. Google devuelve nombre, categoría, horario, rating, web, teléfono y a veces nivel de precio. **No da precios de productos**: los rangos salen de la semilla, de lo que captures («Agregar») o del nivel de precio (tabla en `places.js`, ajústala).
4. Se filtra por `addressHint` de la plaza (en `stores.js`) para no traer negocios de afuera; revisa los marcados «sin categoría».

## Activar la nube (Supabase)
1. Crea un proyecto gratis → SQL Editor → pega `schema.sql`.
2. Ajustes → Project URL + anon key.
3. Regístrate en Perfil → en SQL: `update profiles set role='admin' where id='<tu-uuid>';` (sólo admins escriben tiendas/ofertas; el rol no se puede auto-asignar).
4. Tip: en Authentication desactiva la confirmación por correo mientras pruebas.

## Honestidad de datos
- Rangos por producto de la semilla = **estimaciones mías**, no precios reales. Los productos de `menus.js` sin «~» son precios de lista publicados en prensa/apps de reparto (consultados nov-2026); en la tienda pueden ser distintos (sucursal, mostrador vs. reparto, promos vencidas). Cada uno se puede corregir en el código o con «Agregar».
- La semilla trae **Altaria (168, del directorio oficial), Espacio (17) y Villasunción (9)**, tomadas de directorios públicos consultados el 2026-11-18. ✔ = aparece en 2+ fuentes; ? = una sola fuente, confirma en la plaza. Los directorios pueden estar desactualizados (Altaria: lista oficial pegada por el usuario; 60 marcas quedaron «por confirmar» porque su categoría no es evidente y 35 están como «otros» — corrígelas en «Agregar»). Se excluyeron bancos, agencias de viajes, dentistas y escuelas, que no son compras.
- La API key de Google y la anon key se guardan en este navegador; no compartas el zip con tus claves dentro.

## Para crecer a todo México
Agrega la ciudad en `CITIES` y las plazas en `PLAZAS` (con `city` y `addressHint`) — el resto no cambia.

## Prompts de continuación
**Claude Code:** «Lee README.md. Implementa v0.3: panel para tiendas (login de rol `store`, CRUD de sus productos con rangos/precios y cupones), y un mapa interno de Altaria con `zone` por tienda para que el modo ruta calcule el recorrido.»
**Lovable / Base44:** «Web app GastaBot: ciudad › plaza › tienda › productos; chat de presupuesto con combos y ruta; comparador; ofertas con vigencia; roles user/admin/store; usa el esquema de schema.sql.»
